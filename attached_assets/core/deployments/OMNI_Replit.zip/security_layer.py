
def sentinel_scan():
    print("[AI SENTINEL] Monitoring active processes. No threats detected.")
