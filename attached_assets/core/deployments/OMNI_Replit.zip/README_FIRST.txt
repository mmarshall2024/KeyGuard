▶ Upload to Replit
▶ Add .env with API + Stripe Keys
▶ Click RUN
▶ Empire begins.
