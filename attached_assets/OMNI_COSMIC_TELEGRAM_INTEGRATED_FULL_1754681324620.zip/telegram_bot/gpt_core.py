
def omni_logic_core(prompt):
    return "🧠 GPT RESPONSE: " + prompt
